/*
 *             Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
export default{'ne':{'dictionary':{'Restored':'','Empty\x20document':'','Initial\x20revision':'','Compare\x20against\x20selected':'','Name\x20this\x20revision':'','Revision\x20creator':'','Revision\x20author':'','Revision\x20name':'','Name\x20of\x20the\x20revision':'','optional':'','Save\x20current\x20revision':'','Open\x20revision\x20history':'','Revision\x20history':'','Suggested\x20by':'','Added\x20by':'','Removed\x20by':'','Loading...':'','No\x20changes':'','NUMBER_OF_CHANGES':['',''],'X_OF_Y_CHANGES':'०%\x20मध्ये\x20१%','Show\x20previous\x20change':'','Show\x20next\x20change':'','Total':'','EDIT_X_OF_Y_REVISIONS':'','Back\x20to\x20editing':'','Restore\x20this\x20revision':'','PENDING_ACTION_REVISION_HISTORY':'','Enter\x20the\x20revision\x20name':'','The\x20revision\x20name\x20cannot\x20be\x20empty.':''},'getPluralForm':_0x1528d3=>0x1!=_0x1528d3}};
/*
 *             Copyright (c) 2003-2024, CKSource Holding sp. z o.o. All rights reserved.
 *
 *
 *
 *
 *          +---------------------------------------------------------------------------------+
 *          |                                                                                 |
 *          |                                 Hello stranger!                                 |
 *          |                                                                                 |
 *          |                                                                                 |
 *          |   What you're currently looking at is the source code of a legally protected,   |
 *          |    proprietary software. Any attempts to deobfuscate / disassemble this code    |
 *          |               are forbidden and will result in legal consequences.              |
 *          |                                                                                 |
 *          |                                                                                 |
 *          +---------------------------------------------------------------------------------+
 *
 *
 *
 *
 */
export default{'ti':{'dictionary':{'Restored':'','Empty\x20document':'','Initial\x20revision':'','Compare\x20against\x20selected':'','Name\x20this\x20revision':'','Revision\x20creator':'','Revision\x20author':'','Revision\x20name':'','Name\x20of\x20the\x20revision':'','optional':'','Save\x20current\x20revision':'','Open\x20revision\x20history':'','Revision\x20history':'','Suggested\x20by':'','Added\x20by':'','Removed\x20by':'','Loading...':'','No\x20changes':'','NUMBER_OF_CHANGES':['',''],'X_OF_Y_CHANGES':'','Show\x20previous\x20change':'','Show\x20next\x20change':'','Total':'','EDIT_X_OF_Y_REVISIONS':'ኣርም','Back\x20to\x20editing':'','Restore\x20this\x20revision':'','PENDING_ACTION_REVISION_HISTORY':'','Enter\x20the\x20revision\x20name':'','The\x20revision\x20name\x20cannot\x20be\x20empty.':'','Comment\x20editor':'','NUMBER_OF_COMMENTS':['',''],'TOO_LONG_COMMENT_ALERT':'','Reply...':'','Reply\x20to\x20reopen\x20discussion...':'','Write\x20a\x20comment...':'','Comment\x20was\x20made\x20on\x20an\x20element':'','Edit':'ኣርም','Resolve':'','Reopen':'','Remove':'','Reply':'','Delete\x20comment?':'','Delete\x20comment\x20thread?':'','Marked\x20as\x20resolved':'','Comment':'','ENTER_COMMENT_ANNOUNCEMENT':'','LEAVE_COMMENT_ANNOUNCEMENT':'','PENDING_ACTION_COMMENT_THREAD':'','EXTERNAL_COMMENT':'','EXTERNAL_IMPORT_WORD_COMMENT':'','EXTERNAL_AVATAR':'','EXTERNAL_IMPORT_WORD_AVATAR':'','COMMENTS_ARCHIVE':'','EMPTY_COMMENTS_ARCHIVE':'','Edit\x20or\x20review':'ኣርም\x20ወይ\x20ተመልከት','Improve\x20writing':'ጽሑፍ\x20ኣመሓይሽ','Make\x20shorter':'ኣሕጽር','Make\x20longer':'ኣንውሕ','Simplify\x20language':'','Generate\x20from\x20selection':'','Summarize':'','Continue':'ቀጽል','Change\x20tone':'','Professional':'','Casual':'','Direct':'','Confident':'','Friendly':'','Change\x20style':'','Business':'','Legal':'','Journalism':'ጋዜጠኝነት','Poetic':'','Translate':'','Translate\x20to\x20%0':'','English':'','Spanish':'','German':'','Portuguese':'','French':'','Simplified\x20Chinese':'','Hindi':'','Arabic':'','AI\x20Assistant':'','AI\x20Commands':'','Ask\x20AI\x20to\x20edit\x20or\x20generate':'','Ask\x20AI\x20to\x20improve\x20generated\x20text':'','Copy':'ቅዳሕ','Submit':'ኣረክብ','Insert\x20below':'','Try\x20again':'ደጊምካ\x20ፈትን','Stop':'ኣቑም','AI\x20is\x20writing...':'ብ\x20AI\x20ምጽሓፍ...\x20','AI\x20is\x20writing':'','Generated\x20content:\x20%0':'','Error\x20during\x20AI\x20content\x20generation:\x20%0':'','History':'ታሪኽ','Empty\x20history':'ታሪኽ\x20ኣወግድ','Ask\x20AI\x20and\x20your\x20prompts\x20will\x20be\x20listed\x20here\x20for\x20you\x20to\x20use\x20later.':'','Prompt\x20history':'','Search\x20AI\x20command':'','No\x20commands\x20found':'','No\x20commands\x20available':'','%0\x20commands\x20found':'','AI_REPLACE_CONTENT':'ተክእ','AI_INSERT_CONTENT':'የእትው','AI_ERROR_GET_HEADERS':'','AI_ERROR_GET_PARAMETERS':'','AI_ERROR_UNSUPPORTED_MODEL':'','AI_ERROR_CONTEXT_LENGTH':'ዝተመረጸ\x20ጽሑፍ\x20ካብ\x20ዓቐን\x20ንላዕሊ\x20ነዊሕ\x20እዩ','AI_ERROR_MODERATION':'','AI_ERROR_FAILED':''},'getPluralForm':_0x273293=>_0x273293>0x1}};
import { Test } from 'import-alias';
import { Test2 } from './non-alias';
export { Test3 } from 'import-alias';
await __non_webpack_import__("./non-alias");
